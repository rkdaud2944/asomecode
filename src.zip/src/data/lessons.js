export default [
    {
        id: 0,
        category: "AsomeKit",
        title: "SW코딩 왜 배워야 할까요?",
    },
    {
        id: 1,
        category: "AsomeKit",
        title: "프로그래밍과 사물인터넷은 뭔가요?",
    },
    {
        id: 2,
        category: "AsomeKit",
        title: "어썸보드와 어썸코드 사용 준비하기",
    },
    {
        id: 3,
        category: "AsomeKit",
        title: "LED 제어하기와 신호등 만들기",
    },
    {
        id: 4,
        category: "AsomeKit",
        title: "버튼 스위치 이용하기와 주사위 만들기",
    },
];