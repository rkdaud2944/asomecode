
// import serial from "@/globals/serial";
// import ble from "@/globals/ble";
// import {useConnectStore} from '@/store/connect-store'