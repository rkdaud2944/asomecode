import mitt from 'mitt';

const istance = mitt();

export default istance;
