/**
 * 전역에서 사용되는 데이터를 관리하는 객체
 */
export default {
    currentPath: "",
};
