export default {
    user: [
        { name: 'id', align: 'center', label: 'id', field: 'id' },
        { name: 'title', align: 'left', label: '제목', field: 'title' },
        { name: 'author', align: 'center', label: '작성자', field: 'author' },
        { name: 'created_at', align: 'center', label: '작성일', field: 'created_at' },
        { name: 'views', align: 'center', label: '조회수', field: 'views' },
    ],
};